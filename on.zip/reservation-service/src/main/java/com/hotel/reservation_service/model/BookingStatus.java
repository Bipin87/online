package com.hotel.reservation_service.model;

public enum BookingStatus {
    PENDING,
    BOOKED,
    CANCELLED,
}
