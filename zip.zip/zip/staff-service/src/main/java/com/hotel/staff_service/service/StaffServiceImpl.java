package com.hotel.staff_service.service;

import com.hotel.staff_service.dto.StaffRequestDTO;
import com.hotel.staff_service.dto.StaffResponseDTO;
import com.hotel.staff_service.exception.StaffNotFoundException;
import com.hotel.staff_service.model.Staff;
import com.hotel.staff_service.repository.StaffRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StaffServiceImpl implements StaffService {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public StaffResponseDTO createStaff(StaffRequestDTO staffRequestDTO) {
        // Map request DTO to entity
        Staff staff = new Staff();
        staff.setFullName(staffRequestDTO.getFullName());
        staff.setEmail(staffRequestDTO.getEmail());
        staff.setSalary(staffRequestDTO.getSalary());
        staff.setAddress(staffRequestDTO.getAddress());
        staff.setAge(staffRequestDTO.getAge());
        staff.setOccupation(staffRequestDTO.getOccupation());
        staff.setIdProof(staffRequestDTO.getIdProof());
        staff.setIdProofNumber(staffRequestDTO.getIdProofNumber());
        staff.setPhoneNumber(staffRequestDTO.getPhoneNumber());
        staff.setJoiningDate(staffRequestDTO.getJoiningDate());
        staff.setDepartment(staffRequestDTO.getDepartment());

        // Save entity to database
        Staff savedStaff = staffRepository.save(staff);

        // Convert saved entity to response DTO
        return modelMapper.map(savedStaff, StaffResponseDTO.class);
    }

    @Override
    public StaffResponseDTO getStaffById(Long id) {
        // Fetch staff by ID or throw exception if not found
        Staff staff = staffRepository.findById(id)
                .orElseThrow(() -> new StaffNotFoundException("Staff not found with id: " + id));
        return modelMapper.map(staff, StaffResponseDTO.class);
    }

    @Override
    public List<StaffResponseDTO> getAllStaff() {
        // Fetch all staff entities
        List<Staff> staffList = staffRepository.findAll();

        // Map each entity to response DTO and return list
        return staffList.stream()
                .map(staff -> modelMapper.map(staff, StaffResponseDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public StaffResponseDTO updateStaff(Long id, StaffRequestDTO staffRequestDTO) {
        // Fetch existing staff or throw exception if not found
        Staff staff = staffRepository.findById(id)
                .orElseThrow(() -> new StaffNotFoundException("Staff not found with id: " + id));

        // Update staff fields
        staff.setFullName(staffRequestDTO.getFullName());
        staff.setEmail(staffRequestDTO.getEmail());
        staff.setSalary(staffRequestDTO.getSalary());
        staff.setAddress(staffRequestDTO.getAddress());
        staff.setAge(staffRequestDTO.getAge());
        staff.setOccupation(staffRequestDTO.getOccupation());
        staff.setIdProof(staffRequestDTO.getIdProof());
        staff.setIdProofNumber(staffRequestDTO.getIdProofNumber());
        staff.setPhoneNumber(staffRequestDTO.getPhoneNumber());
        staff.setJoiningDate(staffRequestDTO.getJoiningDate());
        staff.setDepartment(staffRequestDTO.getDepartment());

        // Save updated staff entity
        Staff updatedStaff = staffRepository.save(staff);

        // Convert updated entity to response DTO
        return modelMapper.map(updatedStaff, StaffResponseDTO.class);
    }

    @Override
    public void deleteStaff(Long id) {
        // Fetch staff or throw exception if not found
        Staff staff = staffRepository.findById(id)
                .orElseThrow(() -> new StaffNotFoundException("Staff not found with id: " + id));

        // Delete staff entity
        staffRepository.delete(staff);
    }
}
