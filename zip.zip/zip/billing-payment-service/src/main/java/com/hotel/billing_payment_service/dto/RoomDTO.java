package com.hotel.billing_payment_service.dto;

public class RoomDTO {
    private double pricePerNight;

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }
}
