package com.hotel.authentication.controller;

import com.hotel.authentication.dto.LoginRequestDTO;
import com.hotel.authentication.dto.LoginResponseDTO;
import com.hotel.authentication.dto.RegisterRequestDTO;
import com.hotel.authentication.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@Valid @RequestBody RegisterRequestDTO registerUser) {
        String message = authService.register(registerUser);
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return ResponseEntity.ok(response);
    }

    // Endpoint to log in a user
    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login(@Valid @RequestBody LoginRequestDTO user) {
        LoginResponseDTO loginResponse = authService.login(user);
        return ResponseEntity.ok(loginResponse);
    }

}
