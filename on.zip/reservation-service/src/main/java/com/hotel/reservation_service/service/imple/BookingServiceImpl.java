package com.hotel.reservation_service.service.imple;

import com.hotel.reservation_service.dto.*;
import com.hotel.reservation_service.exception.*;
import com.hotel.reservation_service.model.Booking;
import com.hotel.reservation_service.model.BookingStatus;
import com.hotel.reservation_service.model.Guest;
import com.hotel.reservation_service.repository.BookingRepository;
import com.hotel.reservation_service.repository.GuestRepository;
import com.hotel.reservation_service.service.BookingService;
import com.hotel.reservation_service.service.GuestService;
import com.hotel.reservation_service.service.RoomServiceClient;
import com.hotel.reservation_service.dto.BookingRequestDTO;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RoomServiceClient roomServiceClient;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private GuestService guestService;

    @Autowired
    private GuestRepository guestRepository;

    @Override
    public BookingResponseDTO createBooking(String roomType, BookingRequestDTO bookingRequestDTO) {
        // Fetch an available room of the requested type from Room Service
        RoomResponseDto room = roomServiceClient.getAvailableRoomByType(roomType);

        // If no room available, throw exception
        if (room == null || !room.isAvailable()) {
            throw new RoomNotAvailableException("No available room of type: " + roomType);
        }

        // Validate guest details in booking request
        GuestRequestDTO guestDetail = bookingRequestDTO.getGuest();
        if (guestDetail == null) {
            throw new GuestDetailsMissingException("Guest details are missing.");
        }

        // Create guest using Guest Service and map response to Guest entity
        GuestResponseDTO guestResponse = guestService.createGuest(guestDetail);
        Guest guestCreated = modelMapper.map(guestResponse, Guest.class);

        // Prepare booking entity
        Booking booking = new Booking();
        booking.setRoomId(room.getRoomId());
        booking.setGuestId(guestCreated.getGuestId());
        booking.setBookingStatus(BookingStatus.PENDING);
        booking.setCheckinDate(bookingRequestDTO.getCheckinDate());
        booking.setCheckoutDate(bookingRequestDTO.getCheckoutDate());
        booking.setNumGuests(bookingRequestDTO.getNumGuests());
        booking.setCreatedAt(LocalDateTime.now());

        // Mark room as unavailable
        roomServiceClient.updateRoomAvailability(room.getRoomId(), false);
        room.setAvailable(false);

        // Save booking
        bookingRepository.save(booking);

        // Build and return response DTO
        BookingResponseDTO newBooking = new BookingResponseDTO(
                booking.getBookingId(),
                guestResponse,
                room,
                booking.getCheckinDate(),
                booking.getCheckoutDate(),
                booking.getNumGuests(),
                "PENDING"
        );

        return newBooking;
    }

    @Override
    public BookingResponseDTO getBookingById(Long bookingId) {
        // Fetch booking by ID or throw exception if not found
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + bookingId));

        // Fetch associated guest or throw exception if not found
        Guest guest = guestRepository.findById(booking.getGuestId())
                .orElseThrow(() -> new GuestNotFoundException("Guest not found."));

        // Fetch room details via Room Service
        RoomResponseDto room = roomServiceClient.getRoomById(booking.getRoomId());

        // Build and return BookingResponseDTO
        return new BookingResponseDTO(
                booking.getBookingId(),
                modelMapper.map(guest, GuestResponseDTO.class),
                room,
                booking.getCheckinDate(),
                booking.getCheckoutDate(),
                booking.getNumGuests(),
                booking.getBookingStatus().name()
        );
    }

    @Override
    public List<BookingResponseDTO> getAllBookings() {
        // Retrieve all bookings, map each to BookingResponseDTO
        return bookingRepository.findAll().stream().map(booking -> {
            Guest guest = guestRepository.findById(booking.getGuestId())
                    .orElseThrow(() -> new GuestNotFoundException("Guest not found."));

            RoomResponseDto room = roomServiceClient.getRoomById(booking.getRoomId());

            return new BookingResponseDTO(
                    booking.getBookingId(),
                    modelMapper.map(guest, GuestResponseDTO.class),
                    room,
                    booking.getCheckinDate(),
                    booking.getCheckoutDate(),
                    booking.getNumGuests(),
                    booking.getBookingStatus().name()
            );
        }).collect(Collectors.toList());
    }

    public void updateBookingStatus(Long bookingId) {
        // Find booking by ID or throw exception
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for ID: " + bookingId));

        // Update booking status to BOOKED (assumed after payment)
        booking.setBookingStatus(BookingStatus.BOOKED);
        bookingRepository.save(booking);
    }

    @Override
    public BookingResponseDTO updateBooking(Long bookingId, @Valid BookingRequestDTO bookingRequestDTO) {
        // Find booking or throw exception
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + bookingId));

        // Update booking details
        booking.setCheckinDate(bookingRequestDTO.getCheckinDate());
        booking.setCheckoutDate(bookingRequestDTO.getCheckoutDate());
        booking.setNumGuests(bookingRequestDTO.getNumGuests());
        booking.setUpdatedAt(LocalDateTime.now());

        Booking updated = bookingRepository.save(booking);

        // Fetch guest details
        Guest guest = guestRepository.findById(booking.getGuestId())
                .orElseThrow(() -> new GuestNotFoundException("Guest not found."));

        // Fetch room details
        RoomResponseDto room = roomServiceClient.getRoomById(updated.getRoomId());

        // Return updated booking response
        return new BookingResponseDTO(
                updated.getBookingId(),
                modelMapper.map(guest, GuestResponseDTO.class),
                room,
                updated.getCheckinDate(),
                updated.getCheckoutDate(),
                updated.getNumGuests(),
                updated.getBookingStatus().name()
        );
    }

    @Override
    public void deleteBooking(Long bookingId) {
        // Find booking or throw exception, then delete it
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + bookingId));
        bookingRepository.delete(booking);
    }
}
