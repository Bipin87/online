package com.hotel.roomService.controller;

import com.hotel.roomService.dto.RoomRequestDto;
import com.hotel.roomService.dto.RoomResponseDto;
import com.hotel.roomService.service.RoomService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms") // Base URL for all room-related APIs
public class RoomController {
    @Autowired
    private RoomService roomService;

    // Create a new room
    @PostMapping
    public ResponseEntity<RoomResponseDto> createRoom(@Valid @RequestBody RoomRequestDto roomRequestDto) {
        return ResponseEntity.ok(roomService.createRoom(roomRequestDto));
    }

    // Get room details by room ID
    @GetMapping("/{roomId}")
    public ResponseEntity<RoomResponseDto> getRoomById(@PathVariable Long roomId) {
        return ResponseEntity.ok(roomService.getRoomById(roomId));
    }

    // Get available room by room type (used while booking)
    @GetMapping("/available")
    public ResponseEntity<RoomResponseDto> getRoomByType(@RequestParam String roomType) {
        RoomResponseDto room = roomService.findRoomByType(roomType);
        System.out.println("Finding rooms in ROOM_SERVICE");
        return ResponseEntity.ok(room);
    }

    // Get available room by room type (used while booking)
    @GetMapping("/availableRooms")
    public ResponseEntity<RoomResponseDto> getAvailableRoomByType(@RequestParam String roomType) {
        RoomResponseDto room = roomService.findAvailableRoomByType(roomType);
        return ResponseEntity.ok(room);
    }



    // Update room availability (true or false)
    @PutMapping("/{roomId}/availability")
    public ResponseEntity<Void> updateRoomAvailability(@PathVariable Long roomId, @RequestParam boolean available) {
        roomService.updateRoomAvailability(roomId, available);
        return ResponseEntity.ok().build();
    }

    // Get list of all rooms
    @GetMapping
    public ResponseEntity<List<RoomResponseDto>> getAllRooms() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    // Update room details by room ID
    @PutMapping("/{roomId}")
    public ResponseEntity<RoomResponseDto> updateRoom(@PathVariable Long roomId, @Valid @RequestBody RoomRequestDto roomRequestDto) {
        return ResponseEntity.ok(roomService.updateRoom(roomId, roomRequestDto));
    }
}
