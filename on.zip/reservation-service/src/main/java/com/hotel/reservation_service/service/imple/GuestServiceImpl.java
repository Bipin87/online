package com.hotel.reservation_service.service.imple;

import com.hotel.reservation_service.dto.GuestRequestDTO;
import com.hotel.reservation_service.dto.GuestResponseDTO;
import com.hotel.reservation_service.exception.GuestNotFoundException;
import com.hotel.reservation_service.model.Guest;
import com.hotel.reservation_service.repository.GuestRepository;
import com.hotel.reservation_service.service.GuestService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GuestServiceImpl implements GuestService {

    @Autowired
    private GuestRepository guestRepository;

    @Autowired
    private ModelMapper modelMapper;

    // Create a new guest record from the request DTO and return the response DTO
    @Override
    public GuestResponseDTO createGuest(GuestRequestDTO guestRequestDTO) {
        Guest guest = new Guest();

        guest.setFullName(guestRequestDTO.getFullName());
        guest.setEmail(guestRequestDTO.getEmail());
        guest.setPhone(guestRequestDTO.getPhone());
        guest.setAddress(guestRequestDTO.getAddress());
        guest.setNationality(guestRequestDTO.getNationality());
        guest.setIdProofType(guestRequestDTO.getIdProofType());
        guest.setIdProofNumber(guestRequestDTO.getIdProofNumber());

        Guest savedGuest = guestRepository.save(guest);
        return modelMapper.map(savedGuest, GuestResponseDTO.class);
    }

    // Retrieve a guest by ID, throw exception if not found
    @Override
    public GuestResponseDTO getGuestById(Long guestId) {
        Guest guest = guestRepository.findById(guestId)
                .orElseThrow(() -> new GuestNotFoundException("Guest not found with id: " + guestId));
        return modelMapper.map(guest, GuestResponseDTO.class);
    }

    // Retrieve all guests and map to response DTO list
    @Override
    public List<GuestResponseDTO> getAllGuests() {
        return guestRepository.findAll()
                .stream()
                .map(guest -> modelMapper.map(guest, GuestResponseDTO.class))
                .collect(Collectors.toList());
    }

    // Update guest details for the given ID, throw exception if guest not found
    @Override
    public GuestResponseDTO updateGuest(Long guestId, GuestRequestDTO guestRequestDTO) {
        Guest guest = guestRepository.findById(guestId)
                .orElseThrow(() -> new GuestNotFoundException("Guest not found with id: " + guestId));

        guest.setFullName(guestRequestDTO.getFullName());
        guest.setEmail(guestRequestDTO.getEmail());
        guest.setPhone(guestRequestDTO.getPhone());
        guest.setAddress(guestRequestDTO.getAddress());
        guest.setNationality(guestRequestDTO.getNationality());
        guest.setIdProofType(guestRequestDTO.getIdProofType());
        guest.setIdProofNumber(guestRequestDTO.getIdProofNumber());

        Guest updatedGuest = guestRepository.save(guest);

        return modelMapper.map(updatedGuest, GuestResponseDTO.class);
    }

    // Delete a guest by ID, throw exception if not found
    @Override
    public void deleteGuest(Long guestId) {
        Guest guest = guestRepository.findById(guestId)
                .orElseThrow(() -> new GuestNotFoundException("Guest not found with id: " + guestId));
        guestRepository.delete(guest);
    }
}
